============================
README FOR CONTENT EXTRACTOR
============================

To use the content extractor through the console, the following format 
must be used:

	java ContentExtractor [input file] [output file] {settings file}

The input file and the output file are necessary but the settings file is 
optional. The default settings file is settings.txt. In order to change 
the settings without the settings GUI provided in the Proxy, the file must be 
directly edited. The file is saved using a Java Properties file. See the 
Java APIs for the proper format.
